#ifndef BASICX_SYSLOG_SYSLOG_H
#define BASICX_SYSLOG_SYSLOG_H

#include <stdint.h> // int32_t, int64_t

#include <common/compile.h>

namespace basicx {

	class SysLog_P;

	enum BASICX_SYSLOG_EXPIMP syslog_level {
		n_debug = '0', n_info = '1', n_hint = '2', n_warn = '3', n_error = '4', n_fatal = '5',
		c_debug = 'D', c_info = 'I', c_hint = 'H', c_warn = 'W', c_error = 'E', c_fatal = 'F',
	};

	class BASICX_SYSLOG_EXPIMP SysLog_K // kernel
	{
	private:
		SysLog_K() {};
		
	public:
		SysLog_K( std::string log_name );
		~SysLog_K();

	private:
		SysLog_P * m_syslog_p;
	};

	class BASICX_SYSLOG_EXPIMP SysLog_D // dynamic
	{
	private:
		SysLog_D() {};
		
	public:
		SysLog_D( std::string log_name );
		~SysLog_D();

	public:
		void SetThreadSafe( bool thread_safe ); // Ĭ�� true
		void SetLocalCache( bool local_cache ); // Ĭ�� true
		void SetActiveFlush( bool active_flush ); // Ĭ�� false
		void SetWorkThreads( size_t work_threads ); // Ĭ�� 1
		void SetInitCapacity( uint32_t init_capacity ); // Ĭ�� 8192
		void InitSysLog( std::string app_name, std::string app_version, std::string app_company, std::string app_copyright ); // ���úò������ٵ���
		void PrintSysInfo();
		void WriteSysInfo();
		void ClearScreen( short row, short col, bool print_head = false, int32_t wait = 0 ); // �ȴ�������
		// 0������(debug)��1����Ϣ(info)��2����ʾ(hint)��3������(warn)��4������(error)��5������(fatal)
		void LogPrint( syslog_level log_level, std::string& log_cate, std::string& log_info, bool log_move = false );
		void LogWrite( syslog_level log_level, std::string& log_cate, std::string& log_info, bool log_move = false );

	private:
		SysLog_P * m_syslog_p;
	};

	class BASICX_SYSLOG_EXPIMP SysLog_S // static
	{
	private:
		SysLog_S() {};
		
	public:
		SysLog_S( std::string log_name );
		~SysLog_S();

	public:
		static SysLog_S* GetInstance();

	public:
		void SetThreadSafe( bool thread_safe ); // Ĭ�� true
		void SetLocalCache( bool local_cache ); // Ĭ�� true
		void SetActiveFlush( bool active_flush ); // Ĭ�� false
		void SetWorkThreads( size_t work_threads ); // Ĭ�� 1
		void SetInitCapacity( uint32_t init_capacity ); // Ĭ�� 8192
		void InitSysLog( std::string app_name, std::string app_version, std::string app_company, std::string app_copyright ); // ���úò������ٵ���
		void PrintSysInfo();
		void WriteSysInfo();
		void ClearScreen( short row, short col, bool print_head = false, int32_t wait = 0 ); // �ȴ�������
		// 0������(debug)��1����Ϣ(info)��2����ʾ(hint)��3������(warn)��4������(error)��5������(fatal)
		void LogPrint( syslog_level log_level, std::string& log_cate, std::string& log_info, bool log_move = false );
		void LogWrite( syslog_level log_level, std::string& log_cate, std::string& log_info, bool log_move = false );

	private:
		SysLog_P* m_syslog_p;
		static SysLog_S* m_instance;
	};

} // namespace basicx

#endif // BASICX_SYSLOG_SYSLOG_H
