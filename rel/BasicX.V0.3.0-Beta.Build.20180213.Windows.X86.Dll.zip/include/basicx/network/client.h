#ifndef BASICX_NETWORK_CLIENT_H
#define BASICX_NETWORK_CLIENT_H

#include <string>
#include <stdint.h>

#include <common/compile.h>

namespace basicx {

	#pragma pack( push )
	#pragma pack( 1 )

	struct NetClientCfg // ��������������� // ��Ա�������ᱻ��ֵ
	{
		int32_t m_log_test;
		int32_t m_heart_check_time;
		size_t m_max_msg_cache_number;
		int32_t m_io_work_thread_number;
		int32_t m_client_connect_timeout; // ����
		// �ͻ��˲���
		size_t m_max_connect_total_c;
		size_t m_max_data_length_c;
	};

	struct NetClientInfo // ���������¼�����
	{
		int32_t m_info_type;
		std::string m_node_type;
		int32_t m_identity;
		std::string m_endpoint_l;
		std::string m_endpoint_r;

		NetClientInfo( int32_t info_type, std::string& node_type, int32_t identity, std::string& endpoint_l, std::string& endpoint_r );
	};

	struct NetClientData // ����������������
	{
		std::string m_node_type;
		int32_t m_identity;
		int32_t m_code;
		std::string m_data;

		NetClientData( std::string& node_type, int32_t identity, int32_t code, std::string& data );
	};

	#pragma pack( pop )

	class BASICX_NETWORK_EXPIMP NetClient_X
	{
	public:
		NetClient_X();
		virtual ~NetClient_X();

		virtual void OnNetClientInfo( NetClientInfo& net_client_info ) = 0;
		virtual void OnNetClientData( NetClientData& net_client_data ) = 0;
	};

	struct ConnectInfo;

	class NetClient_P;

	class BASICX_NETWORK_EXPIMP NetClient
	{
	public:
		NetClient();
		~NetClient();

	public:
		void ComponentInstance( NetClient_X* net_client_x );

	public:
		void StartNetwork( NetClientCfg& config );
		bool IsNetworkStarted();
		bool IsConnectAvailable( ConnectInfo* connect_info );

	public:
		bool Client_CanAddConnect();
		bool Client_CanAddServer( std::string address_r, int32_t port_r ); // ֻ������Զ��һ����ַһ���˿�ֻһ������ʱ���
		bool Client_AddConnect( std::string address_r, int32_t port_r, std::string node_type_r );
		void Client_SetAutoReconnect( bool auto_reconnect );

		int32_t Client_SendDataAll( int32_t type, int32_t code, std::string& data );
		int32_t Client_SendData( ConnectInfo* connect_info, int32_t type, int32_t code, std::string& data );

		void Client_CloseAll();
		void Client_Close( ConnectInfo* connect_info );
		void Client_Close( int32_t identity );

		size_t Client_GetConnectCount();
		ConnectInfo* Client_GetConnect( int32_t identity );

	private:
		NetClient_P* m_net_client_p;
	};

} // namespace basicx

#endif // BASICX_NETWORK_CLIENT_H
