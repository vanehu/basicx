#ifndef COMMON_COMMON_H
#define COMMON_COMMON_H

#include "Format/Format.hpp"
#include "PugiXml/pugixml.hpp"

namespace basicx {

} // namespace basicx

#endif // COMMON_COMMON_H
