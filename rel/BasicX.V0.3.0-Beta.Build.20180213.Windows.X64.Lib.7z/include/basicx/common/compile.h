#ifndef BASICX_COMMON_COMPILE_H
#define BASICX_COMMON_COMPILE_H

//---------- ������� ----------//

#define BASICX_TIMERS_EXP
//#define BASICX_TIMERS_IMP

#define BASICX_SYSLOG_EXP
//#define BASICX_SYSLOG_IMP

#define BASICX_NETWORK_EXP
//#define BASICX_NETWORK_IMP

#define BASICX_PLUGINS_EXP
//#define BASICX_PLUGINS_IMP

//---------- ������ ----------//

//---------- ���ý��� ----------//

#ifdef BASICX_SYSLOG_EXP
    #define BASICX_SYSLOG_EXPIMP __declspec(dllexport)
#endif

#ifdef BASICX_SYSLOG_IMP
    #define BASICX_SYSLOG_EXPIMP __declspec(dllimport)
#endif

//------------------------------//

#ifdef BASICX_TIMERS_EXP
    #define BASICX_TIMERS_EXPIMP __declspec(dllexport)
#endif

#ifdef BASICX_TIMERS_IMP
    #define BASICX_TIMERS_EXPIMP __declspec(dllimport)
#endif

//------------------------------//

#ifdef BASICX_NETWORK_EXP
    #define BASICX_NETWORK_EXPIMP __declspec(dllexport)
#endif

#ifdef BASICX_NETWORK_IMP
    #define BASICX_NETWORK_EXPIMP __declspec(dllimport)
#endif

//------------------------------//

#ifdef BASICX_PLUGINS_EXP
    #define BASICX_PLUGINS_EXPIMP __declspec(dllexport)
#endif

#ifdef BASICX_PLUGINS_IMP
    #define BASICX_PLUGINS_EXPIMP __declspec(dllimport)
#endif

//------------------------------//

#endif // BASICX_COMMON_COMPILE_H
