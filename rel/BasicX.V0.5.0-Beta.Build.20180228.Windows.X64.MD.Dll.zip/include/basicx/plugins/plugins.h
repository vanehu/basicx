#ifndef BASICX_PLUGINS_PLUGINS_H
#define BASICX_PLUGINS_PLUGINS_H

#include <string>
#include <stdint.h> // int32_t, int64_t

#include <common/compile.h>
//#include <mission/mission.h> //mission//

namespace basicx {

	class BASICX_PLUGINS_EXPIMP Plugins_X
	{
	private:
		Plugins_X();

	public:
		Plugins_X( std::string plugin_name );
		virtual ~Plugins_X();

	public:
		virtual bool Initialize() = 0;
		virtual bool InitializeExt() = 0;
		virtual bool StartPlugin() = 0;
		virtual bool IsPluginRun() = 0;
		virtual bool StopPlugin() = 0;
		virtual bool UninitializeExt() = 0;
		virtual bool Uninitialize() = 0;
		virtual bool AssignTask( int32_t task_id, int32_t identity, int32_t code, std::string& data ) = 0;
	};

	class Plugins_P;

	class BASICX_PLUGINS_EXPIMP Plugins //class Plugins : public Mission_X //mission//
	{
	public:
		Plugins();
		~Plugins();

	public:
		static Plugins* GetInstance();

	public:
		void StartPlugins();
		bool IsPluginsStarted();

	public:
		bool LoadAll( std::string folder );
		void StopAll();

		Plugins_X* GetPluginsX( const std::string& plugin_name ) const;
		void SetPluginsX( const std::string& plugin_name, Plugins_X* plugins_x );

	private:
		Plugins_P* m_plugins_p;
		static Plugins* m_instance;
	};

} // namespace basicx

#endif // BASICX_PLUGINS_PLUGINS_H
