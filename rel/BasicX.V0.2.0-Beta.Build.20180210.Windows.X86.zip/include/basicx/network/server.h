#ifndef BASICX_NETWORK_SERVER_H
#define BASICX_NETWORK_SERVER_H

#include <string>
#include <stdint.h>

namespace basicx {

	#pragma pack( push )
	#pragma pack( 1 )

	struct NetServerCfg // ��������������� // ��Ա�������ᱻ��ֵ
	{
		int32_t m_log_test;
		int32_t m_heart_check_time;
		size_t m_max_msg_cache_number;
		int32_t m_io_work_thread_number;
		int32_t m_client_connect_timeout; // ����
		// ����˲���
		size_t m_max_connect_total_s;
		size_t m_max_data_length_s;
	};

	struct NetServerInfo // ���������¼�����
	{
		int32_t m_info_type;
		std::string m_node_type;
		int32_t m_identity;
		std::string m_endpoint_l;
		std::string m_endpoint_r;

		NetServerInfo( int32_t info_type, std::string& node_type, int32_t identity, std::string& endpoint_l, std::string& endpoint_r );
	};

	struct NetServerData // ����������������
	{
		std::string m_node_type;
		int32_t m_identity;
		int32_t m_code;
		std::string m_data;

		NetServerData( std::string& node_type, int32_t identity, int32_t code, std::string& data );
	};

	#pragma pack( pop )

	class NetServer_X
	{
	public:
		NetServer_X();
		virtual ~NetServer_X();

		virtual void OnNetServerInfo( NetServerInfo& net_client_info ) = 0;
		virtual void OnNetServerData( NetServerData& net_client_data ) = 0;
	};

	struct ConnectInfo;

	class NetServer_P;

	class NetServer
	{
	public:
		NetServer();
		~NetServer();

	public:
		void ComponentInstance( NetServer_X* net_server_x );

	public:
		void LogPrint( syslog_level log_level, std::string& log_cate, std::string& log_info, int32_t log_show = 0 );

		void StartNetwork( NetServerCfg& config );
		bool IsNetworkStarted();
		bool IsConnectAvailable( ConnectInfo* connect_info );

	public:
		bool Server_CanAddConnect();
		bool Server_CanAddListen( std::string address_l, int32_t port_l ); // 0.0.0.0
		bool Server_AddListen( std::string address_l, int32_t port_l, std::string node_type_l ); // 0.0.0.0

		int32_t Server_SendDataAll( int32_t type, int32_t code, std::string& data );
		int32_t Server_SendData( ConnectInfo* connect_info, int32_t type, int32_t code, std::string& data );

		void Server_CloseAll();
		void Server_Close( ConnectInfo* connect_info );
		void Server_Close( int32_t identity );

		size_t Server_GetConnectCount();
		ConnectInfo* Server_GetConnect( int32_t identity );

	private:
		NetServer_P* m_net_server_p;
	};

} // namespace basicx

#endif // BASICX_NETWORK_SERVER_H
