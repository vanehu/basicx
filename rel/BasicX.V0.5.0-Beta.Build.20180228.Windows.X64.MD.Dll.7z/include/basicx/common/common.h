#ifndef BASICX_COMMON_COMMON_H
#define BASICX_COMMON_COMMON_H

#include "OTLV4/otlv4.h"
#include "JsonCpp/json.h"
#include "Format/Format.hpp"
#include "PugiXml/pugixml.hpp"

namespace basicx {

} // namespace basicx

#endif // BASICX_COMMON_COMMON_H
