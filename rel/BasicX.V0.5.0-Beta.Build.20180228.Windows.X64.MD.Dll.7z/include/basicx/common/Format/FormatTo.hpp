// FormatLibrary 
// @author bodong 
// this is the wrapper of Format To impl
#pragma once

namespace FormatLibrary
{
    namespace Detail
    {
#define _FL_FORMAT_TO_INDEX_ 1
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 2
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 3
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 4
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 5
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 6
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 7
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 8
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 9
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 10
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 11
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 12
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 13
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 14
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 15
#include "FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_
    }
}