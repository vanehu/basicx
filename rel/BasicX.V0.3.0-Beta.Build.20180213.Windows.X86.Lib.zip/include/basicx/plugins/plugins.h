#ifndef BASICX_PLUGINS_PLUGINS_H
#define BASICX_PLUGINS_PLUGINS_H

#include <string>
#include <stdint.h> // int32_t, int64_t

#include <common/compile.h>
//#include <mission/mission.h> //mission//

namespace basicx {

	class BASICX_PLUGINS_EXPIMP Plugins_X
	{
	private:
		Plugins_X();

	public:
		Plugins_X( std::string plugin_name );
		virtual ~Plugins_X();

	public:
		virtual bool Initialize() = 0;
		virtual bool InitializeExt() = 0;
		virtual bool StartPlugin() = 0;
		virtual bool IsPluginRun() = 0;
		virtual bool StopPlugin() = 0;
		virtual bool UninitializeExt() = 0;
		virtual bool Uninitialize() = 0;
		virtual bool AssignTask( int32_t task_id, int32_t identity, int32_t code, std::string& data ) = 0;
	};

	class Plugins_P;

	class BASICX_PLUGINS_EXPIMP Plugins //class Plugins : public Mission_X //mission//
	{
	public:
		Plugins();
		~Plugins();

	public:
		static Plugins* GetInstance();

	public:
		void StartPlugins();
		bool IsPluginsStarted();

	public:
		//std::vector<std::string> GetErrorInfos() const;
		//bool AddErrorInfo( const std::string& error_info );

		//void SetInfoFileExt( const std::string& info_file_ext );
		//std::string GetInfoFileExt() const;
		//void SetPluginFolder( const std::string& plugin_folder );
		//std::string GetPluginFolder() const;

		//void SetPluginInfoPaths( const std::string& plugin_folder );
		//void FindPluginPaths( std::string folder_path );
		//std::vector<std::string> GetPluginInfoPaths() const;
		//bool LoadPluginSetting();
		//std::vector<std::string> GetDisabledPlugins() const;
		//std::vector<std::string> GetForceEnabledPlugins() const;
		//bool WritePluginSetting();

		//void LoadPluginInfos();
		//void ResolveDepends();
		//std::vector<PluginInfo*> LoadQueue();
		//bool LoadQueue( PluginInfo* plugin_info, std::vector<PluginInfo*>& queue, std::vector<PluginInfo*>& cycle_check_queue );
		//std::vector<PluginInfo*> GetPluginInfos() const;
		//size_t GetPluginInfosNumber();
		//PluginInfo* GetPluginInfo( size_t index );
		//PluginInfo* FindPluginInfoByName( const std::string& plugin_name );

		bool LoadAll( std::string folder );
		//void LoadPlugins();
		//void LoadPlugin( PluginInfo* plugin_info, PluginInfo::State dest_state );
		void StopAll();

		Plugins_X* GetPluginsX( const std::string& plugin_name ) const;
		void SetPluginsX( const std::string& plugin_name, Plugins_X* plugins_x );

		////void AddUserTaskSend( int32_t task_type, std::string& task_info, std::string& task_data = std::string( "" ) );
		//void OnDeliverTask( int32_t task_id, std::string node_type, int32_t identity, int32_t code, std::string& data );
		//void CommitResult( int32_t task_id, int32_t identity, int32_t code, std::string& data );

	private:
		Plugins_P* m_plugins_p;
		static Plugins* m_instance;
	};

} // namespace basicx

#endif // BASICX_PLUGINS_PLUGINS_H
